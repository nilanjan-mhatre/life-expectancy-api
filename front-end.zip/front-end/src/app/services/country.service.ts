import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs';

@Injectable()
export class CountryService {
  private baseUrl: string = 'http://localhost:8080/SWBackend/jaxrs';

  constructor(private http: Http) {
  }

  // get(id: number): Observable<Person> {
  //   let person$ = this.http
  //     .get(`${this.baseUrl}/Person/${id}`, {headers: this.getHeaders()})
  //     .map(mapPerson);
  //     return person$;
  // }

  getAll(): Observable<Response> {
    return this.http.get(`${this.baseUrl}/countries`)
  }

  getMinimumExpectancy(dob:string): Observable<Response> {
    return this.http.get(`${this.baseUrl}/min-life-expectancy-for-females/` + dob)
  }


  private getHeaders() {
    let headers = new Headers();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');
    return headers;
  }
}

