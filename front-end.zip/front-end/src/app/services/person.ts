export interface Person {
  id: number;
  name: string;
  gender: string;
  skincolor: string;
  haircolor: string;
  eyecolor: string;
  height: number;
  mass: number;
  birthyear: string;
  totalHours: number;
  rate:number;
  totalPay:number;
}
