import { Component, OnInit, OnDestroy } from '@angular/core';
import { DomSanitizer} from '@angular/platform-browser'

@Component({
  selector: 'graph',
  templateUrl: './graphs.component.html',
  styles: []
})
export class GraphComponent {
  constructor(private sanitizer: DomSanitizer) {
    // this.html = sanitizer.bypassSecurityTrustHtml('<h1>DomSanitizer</h1><script>ourSafeCode()</script>') ;
  }
  title = 'front-end';

}
