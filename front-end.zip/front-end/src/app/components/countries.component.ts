import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CountryService } from '../services/country.service';


@Component({
  selector: 'countries',
  templateUrl: './countries.component.html',
  styles: []
})
export class CountryComponent implements OnInit, OnDestroy {

  countryList: String[];
  sub: any;
  sex: string;
  dob: string;
  minimumExpectancy: string;
  count:string;

  constructor(private countryService: CountryService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.sex = "female";
    this.countryService
      .getAll()
      .subscribe(p => {
        let arr: string = JSON.parse(JSON.stringify(p))._body;
        arr = arr.replace(/\[/g, '');
        arr = arr.replace(/\]/g, "");
        arr = arr.replace(/\"/g, "");
        this.countryList = arr.split(",");
      });
  }

  getMinimumLifeExpectancy() {
    console.log(this.dob);
    this.minimumExpectancy = "";
    this.count = "";
    this.countryService
    .getMinimumExpectancy(this.dob)
    .subscribe(p => {
      let str:string = JSON.parse(JSON.stringify(p))._body;
      let ar:string[] = str.split(";");
      this.minimumExpectancy = ar[0];
      this.count = ar[1];

    });
  }

  add(value: string) {
    this.dob = value;
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

}
